let pageNum = 1; //declare a variable to hold current page number (current state)
let numPages = 5; //declare a variable to hold total number of pages (states)

function setup() {
  createCanvas(400, 400);
  console.log(pageNum); //during setup, print current page (zero)
}

function preload() {
  
  //let img1
  //let img2
  //let img3
  //let img4
  
  img1 = loadImage('gen0.jpg')
  img2 = loadImage('gen1.png');
  img3 = loadImage('gen 2.png');
  img4 = loadImage('gen 4.png');
  img5 = loadImage('gen 5.png');
}

function draw() {
  
//display something different on current page(current state)
  if(pageNum == 1){
    background(220);
    image(img1, 0,0,800,500)
    text("page 1", 100,100);
  }
 if (pageNum == 2){
   background(220);
   image(img2, 0,0,400,400)
   text("page 2", 100,100);
 } 
  if (pageNum == 3){
    background(220);
    image(img3, 0,0,400,500)
    text("page 3", 100,100);
  }
  if (pageNum == 4){
    background(220);
    image(img4, 0,0,400,400)
    text("page 4, 100,100");
  }
  if (pageNum == 5){
    background(220);
    image(img5, 0,0,400,400)
    text("page 5, 100,100")
  }
}

//mousePressed() function will run each time the mouse is clicked
function mousePressed(){
  //if the numerical value of the current page is less than the total number of pages, we can increment the pageNum variable's value and move to the next page
  if (pageNum < numPages){
    pageNum++;
  }
  
  //otherwise, reset to first page
  else{ 
  pageNum = 1;
}

  //after each clink, print the current page number to the console
  console.log(pageNum);
}